/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Sidebar from './components/Sidebar';
import ChatTab from './components/ChatTab';
import PricingTab from './components/PricingTab';
import TestTab from './components/TestTab';
import ProjectsTab from './components/ProjectsTab';
import SettingsTab from './components/SettingsTab';
import { IonsTab } from './components/IonsTab';
import { motion, AnimatePresence } from 'motion/react';
import { auth, signInWithGoogle } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { LogIn, Zap } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = React.useState('chat');
  const [selectedProjectId, setSelectedProjectId] = React.useState<string | null>(null);
  const [selectedIon, setSelectedIon] = React.useState<any | null>(null);
  const [activeChatId, setActiveChatId] = React.useState<string | null>(null);
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleNewChat = () => {
    setActiveChatId(null);
    setActiveTab('chat');
  };

  const renderTab = () => {
    switch (activeTab) {
      case 'chat':
        return (
          <ChatTab 
            onQuickAction={setActiveTab} 
            projectId={selectedProjectId} 
            onClearProject={() => setSelectedProjectId(null)}
            chatId={activeChatId}
            onChatCreated={(id) => setActiveChatId(id)}
            activeIon={selectedIon}
            onClearIon={() => setSelectedIon(null)}
          />
        );
      case 'pricing':
        return <PricingTab />;
      case 'test':
        return <TestTab />;
      case 'ions':
        return (
          <IonsTab 
            onSelectIon={setSelectedIon}
            activeIonId={selectedIon?.id}
            onNavigateToChat={() => setActiveTab('chat')}
          />
        );
      case 'projects':
        return <ProjectsTab onSelectProject={(id) => { setSelectedProjectId(id); setActiveChatId(null); setActiveTab('chat'); }} />;
      case 'settings':
        return <SettingsTab />;
      default:
        return (
          <ChatTab 
            onQuickAction={setActiveTab} 
            projectId={selectedProjectId} 
            onClearProject={() => setSelectedProjectId(null)}
            chatId={activeChatId}
            onChatCreated={(id) => setActiveChatId(id)}
          />
        );
    }
  };

  if (loading) {
    return (
      <div className="h-screen bg-brand-black flex items-center justify-center">
        <motion.div 
          animate={{ scale: [1, 1.1, 1], opacity: [1, 0.5, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-16 h-16 bg-brand-blue rounded-2xl flex items-center justify-center blue-glow relative overflow-hidden border-2 border-white/10"
        >
          <span className="text-[10px] font-bold text-white/50 absolute top-1.5 left-2.5">3</span>
          <span className="text-3xl font-black text-white mt-1">Li</span>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen bg-brand-black flex flex-col items-center justify-center relative overflow-hidden px-6">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-blue/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-brand-blue/5 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/4" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-8 relative z-10"
        >
          <div className="w-24 h-24 bg-brand-blue rounded-[2rem] flex flex-col items-center justify-center blue-glow mx-auto mb-8 shadow-[0_0_60px_rgba(0,132,255,0.4)] relative overflow-hidden border-4 border-white/10">
            <span className="text-xl font-bold text-white/50 absolute top-2.5 left-4">3</span>
            <span className="text-6xl font-black text-white select-none mt-2">Li</span>
          </div>
          <div className="space-y-4">
            <h1 className="text-5xl font-black tracking-tighter italic">LITHIUM</h1>
            <p className="text-white/50 text-lg max-w-sm mx-auto">Initialize your high-velocity AI workflow. High-speed chat, image synthesis, and more.</p>
          </div>
          
          <button
            onClick={signInWithGoogle}
            className="flex items-center gap-3 bg-white text-black px-8 py-4 rounded-full font-bold hover:scale-105 active:scale-95 transition-all duration-300 shadow-xl"
          >
            <LogIn size={20} />
            Authorize with Google
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-brand-black text-white font-sans overflow-hidden">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        activeChatId={activeChatId}
        onChatSelect={(id) => { setActiveChatId(id); setActiveTab('chat'); }}
        onNewChat={handleNewChat}
      />
      
      <main id="main-content" className="flex-1 relative overflow-hidden flex flex-col">
        {/* Abstract background gradient */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-blue/5 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/4 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-brand-blue/3 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/4 pointer-events-none" />

        <div className="flex-1 overflow-y-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="h-full"
            >
              {renderTab()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
