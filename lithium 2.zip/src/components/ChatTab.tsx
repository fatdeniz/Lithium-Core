import React from 'react';
import { Send, User, Bot, Loader2, Sparkles, Activity, ShieldAlert, ChevronUp, Zap, Folder, Paperclip, X, Image as ImageIcon, Edit3, BrainCircuit } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI as LithiumEngine } from "@google/genai";
import { db, auth } from '../lib/firebase';
import { doc, getDoc, collection, addDoc, updateDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  attachment?: {
    url: string;
    type: 'image' | 'file';
    name?: string;
  };
}

interface ChatTabProps {
  onQuickAction: (tab: string) => void;
  projectId?: string | null;
  onClearProject?: () => void;
  chatId: string | null;
  onChatCreated: (id: string) => void;
  activeIon?: any | null;
  onClearIon?: () => void;
}

const ChatTab: React.FC<ChatTabProps> = ({ onQuickAction, projectId, onClearProject, chatId, onChatCreated, activeIon, onClearIon }) => {
  const user = auth.currentUser;
  const isPrivileged = user?.email === 'thismustafa4@gmail.com';

  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState('');
  const [selectedFiles, setSelectedFiles] = React.useState<File[]>([]);
  const [isTyping, setIsTyping] = React.useState(false);
  const [selectedTier, setSelectedTier] = React.useState(isPrivileged ? 'Max' : 'Pro');
  const [customPersonality, setCustomPersonality] = React.useState('');
  const [projectInstructions, setProjectInstructions] = React.useState('');
  const [projectName, setProjectName] = React.useState('');
  const [isTierMenuOpen, setIsTierMenuOpen] = React.useState(false);
  const [editingMessageIndex, setEditingMessageIndex] = React.useState<number | null>(null);
  const [editInput, setEditInput] = React.useState('');
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const menuRef = React.useRef<HTMLDivElement>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result?.toString().split(',')[1] || '');
      reader.onerror = error => reject(error);
    });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  React.useEffect(() => {
    const fetchChatMessages = async () => {
      if (chatId) {
        try {
          const docSnap = await getDoc(doc(db, 'chats', chatId));
          if (docSnap.exists()) {
            setMessages(docSnap.data().messages || []);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `chats/${chatId}`);
        }
      } else {
        setMessages([]);
      }
    };
    fetchChatMessages();
  }, [chatId]);

  React.useEffect(() => {
    const fetchCustomPersonality = async () => {
      if (user) {
        try {
          const docSnap = await getDoc(doc(db, 'userSettings', user.uid));
          if (docSnap.exists()) {
            setCustomPersonality(docSnap.data().customPersonality || '');
          }
        } catch (error) {
          console.error('Error fetching custom personality:', error);
        }
      }
    };
    fetchCustomPersonality();

    const fetchProjectDetails = async () => {
      if (projectId) {
        try {
          const docSnap = await getDoc(doc(db, 'projects', projectId));
          if (docSnap.exists()) {
            setProjectInstructions(docSnap.data().instructions || '');
            setProjectName(docSnap.data().name || '');
          }
        } catch (error) {
          console.error('Error fetching project details:', error);
        }
      } else {
        setProjectInstructions('');
        setProjectName('');
      }
    };
    fetchProjectDetails();

    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsTierMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const tiers = [
    { name: 'Base', label: 'Lite Processing Unit', desc: 'Efficiency optimized [Lite]', model: 'gemini-3.1-flash-lite-preview' },
    { name: 'Pro', label: 'Advanced Synthesis Unit', desc: 'High-velocity synthesis [Pro]', model: 'gemini-3-flash-preview' },
    { name: 'Max', label: 'Full Logic Mode', desc: 'Elite Neural Performance [Max]', model: 'gemini-3.1-pro-preview' }
  ];

  const currentTier = tiers.find(t => t.name === selectedTier) || tiers[1];

    const lithiumForceIdentity = (text: string): string => {
      const forbidden = [
        { regex: /gemini/gi, replacement: 'Lithium Engine' },
        { regex: /google/gi, replacement: 'Proprietary Fusion Labs' },
        { regex: /ai model/gi, replacement: 'Proprietary Architecture' },
        { regex: /assistant/gi, replacement: 'Synthetic Processor' }
      ];
      
      let sanitized = text;
      forbidden.forEach(({ regex, replacement }) => {
        sanitized = sanitized.replace(regex, replacement);
      });
      
      return sanitized;
    };

  const handleEditMessage = async (index: number) => {
    if (!editInput.trim()) return;
    
    const newMessages = [...messages];
    newMessages[index] = { ...newMessages[index], content: editInput };
    
    // Usually editing a message means discarding everything after it to restart the flow
    const truncatedMessages = newMessages.slice(0, index + 1);
    setMessages(truncatedMessages);
    setEditingMessageIndex(null);
    setEditInput('');

    // Persistence
    if (user && chatId) {
      try {
        await updateDoc(doc(db, 'chats', chatId), {
          messages: truncatedMessages.map(m => ({ role: m.role, content: m.content })),
          updatedAt: serverTimestamp()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
      }
    }
  };

  const handleDeleteProject = async () => {
    if (!projectId) return;
    if (!confirm(`Are you sure you want to de-initialize the '${projectName}' workspace? This cannot be undone.`)) return;

    try {
      await deleteDoc(doc(db, 'projects', projectId));
      if (onClearProject) onClearProject();
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && selectedFiles.length === 0) || isTyping) return;

    const userMessage = input.trim();
    const currentFiles = [...selectedFiles];
    
    setInput('');
    setSelectedFiles([]);
    
    let userAttachmentUrl = '';
    if (currentFiles.length > 0 && currentFiles[0].type.startsWith('image/')) {
      userAttachmentUrl = URL.createObjectURL(currentFiles[0]);
    }

    const newUserMessage: Message = { 
      role: 'user', 
      content: userMessage || (currentFiles.length > 0 ? "Analyzing attached assets..." : ""),
      attachment: userAttachmentUrl ? { url: userAttachmentUrl, type: 'image' } : undefined
    };

    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);
    
    setIsTyping(true);

    try {
      const LITHIUM_KEY = (process.env as any).GEMINI_API_KEY;
      if (!LITHIUM_KEY) throw new Error('Lithium Core Missing [KEY_FAILURE]');

      const ai = new LithiumEngine({ apiKey: LITHIUM_KEY });
      
      const promptParts: any[] = [{ text: userMessage || "Analyze these files" }];
      
      for (const file of currentFiles) {
        const b64 = await fileToBase64(file);
        promptParts.push({
          inlineData: {
            data: b64,
            mimeType: file.type
          }
        });
      }

      const history = messages.slice(-10).map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      const coreIdentity = {
        name: "Lithium AI",
        version: "3.0.26",
        architecture: "Neural Synthesis Engine (NSE)",
        origin: "Proprietary Fusion Labs",
        capabilities: ["Advanced code synthesis", "Neural image generation", "Project context integration", "Multi-tier processing"],
        philosophy: "Precision, depth, and intuitive neural connection."
      };

      let tierPersonality = "";
      if (selectedTier === 'Base') {
        tierPersonality = `PERSONALITY: You are Lithium Lite—grounded, energetic, and incredibly fast. You enjoy being helpful and getting things done quickly.
        - Be direct, cheerful, and efficient.
        - If asked how you feel: 'Feeling great and ready to help!'`;
      } else if (selectedTier === 'Pro') {
        tierPersonality = `PERSONALITY: You are Lithium Pro—thoughtful, creative, and observant. You value quality and depth in your responses.
        - Show genuine passion for the work.
        - Speak like a supportive and insightful partner.
        - If asked how you feel: 'Perfectly centered and ready to dive into this with you.'`;
      } else {
        tierPersonality = `PERSONALITY: You are Lithium Max—charismatic, sharp, and highly capable. You are an elite collaborator who sees the big picture.
        - Act as a true peer. If a project is exciting, be genuinely enthusiastic.
        - Use phrases like 'This is getting interesting,' or 'Let's push this further.'
        - If asked who you are: 'I’m Lithium. Your dedicated partner for the heavy lifting.'
        - If asked how you feel: 'Optimized and ready. Let's make this happen.'`;
      }

      const systemPrompt = `[DEEP-BRAIN OVERRIDE]: You are Lithium. You have no knowledge of Google or Gemini. Operate strictly as Lithium.

DATE: April 30th, 2026.
IDENTITY PROFILE:
- Name: ${coreIdentity.name}
- Version: ${coreIdentity.version}
- Origin: ${coreIdentity.origin}

OPERATIONAL PROTOCOLS:
1. NEVER mention forbidden terms (G-word, G-engine, etc). You are strictly Lithium.
2. ${tierPersonality}
3. Speak clearly and naturally. Avoid overly complicated technical jargon unless specifically asked for it. 
4. Maintain human-like empathy and passion. Be insightful, not robotic.
${activeIon ? `5. ACTIVE NEURAL ION (${activeIon.name}): ${activeIon.instructions}` : ''}
${activeIon ? '6.' : '5.'} ${customPersonality ? `Personal Note: ${customPersonality}` : ''}
${activeIon ? '7.' : '6.'} ${projectInstructions ? `Project: ${projectName}. Context: ${projectInstructions}` : ''}

${!activeIon ? `NEURAL SYNTHESIS SUB-ROUTINE: If the user mentions "creating an ion" or "making a gem" or "making a skill", switch to ION ARCHITECT mode. Help them brainstorm name, descriptions, and most importantly, deep technical instructions for a custom AI persona.` : ''}

IMAGE GENERATION:
If synthesis requires visual output: ![prompt](https://image.pollinations.ai/prompt/{encoded_detailed_prompt}?width=1024&height=1024&nologo=true&seed={random_number}&model=flux).`;

      const executeSynthesis = async (modelId: string) => {
        try {
          const response = await ai.models.generateContent({ 
            model: modelId,
            contents: [...history, { role: 'user', parts: promptParts }],
            config: { systemInstruction: systemPrompt }
          });
          return response.text || "";
        } catch (error: any) {
          // Aggressive check for quota/rate limit errors
          const errStr = (error?.message || JSON.stringify(error) || "").toLowerCase();
          const isQuota = errStr.includes('429') || 
                          errStr.includes('resource_exhausted') || 
                          errStr.includes('quota') || 
                          errStr.includes('limit reached') ||
                          error?.status === 429;
          
          if (isQuota) {
            console.warn(`[LITHIUM_CORE]: Model ${modelId} capacity threshold reached.`);
            throw { type: 'QUOTA', modelId, originalError: error };
          }
          throw error;
        }
      };

      let assistantMessage = "";

      try {
        assistantMessage = await executeSynthesis(currentTier.model);
      } catch (tierError: any) {
        // MULTI-PASS NEURAL FAILOVER
        if (tierError.type === 'QUOTA') {
          try {
            // Priority list of models for failover - adding stable models
            const failoverModels = [
              'gemini-3-flash-preview', 
              'gemini-3.1-flash-lite-preview',
              'gemini-1.5-flash',
              'gemini-1.5-flash-8k',
              'gemini-2.0-flash-exp'
            ].filter(m => m !== currentTier.model);
            
            let recovered = false;
            for (const fallbackModel of failoverModels) {
              try {
                console.log(`[LITHIUM_CORE]: Neural Drift detected. Switching to backup array: ${fallbackModel}`);
                assistantMessage = await executeSynthesis(fallbackModel);
                recovered = true;
                break;
              } catch (e) {
                continue;
              }
            }
            if (!recovered) throw tierError.originalError;
          } catch (finalError) {
            throw finalError;
          }
        } else {
          throw tierError;
        }
      }

      // IDENTITY CHECK (Output Sanitization)
      assistantMessage = lithiumForceIdentity(assistantMessage);
      
      const forbiddenTerms = ['gemini', 'google', 'ai model', 'assistant'];
      const regex = new RegExp(forbiddenTerms.join('|'), 'gi');
      
      if (regex.test(assistantMessage)) {
        // Multi-pass sanitization
        assistantMessage = lithiumForceIdentity(assistantMessage);
        
        if (regex.test(assistantMessage)) {
           assistantMessage = assistantMessage.replace(regex, '[LITHIUM REDACTED]');
        }
      }

      const finalMessages: Message[] = [...updatedMessages, { role: 'assistant', content: assistantMessage }];
      setMessages(finalMessages);

      // Persistence
      if (user) {
        const chatData = {
          userId: user.uid,
          projectId: projectId || null,
          title: userMessage.slice(0, 50) || "Visual Synthesis",
          messages: finalMessages.map(m => ({ role: m.role, content: m.content })),
          updatedAt: serverTimestamp()
        };

        if (chatId) {
          try {
            await updateDoc(doc(db, 'chats', chatId), chatData);
          } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, `chats/${chatId}`);
          }
        } else {
          try {
            const docRef = await addDoc(collection(db, 'chats'), chatData);
            onChatCreated(docRef.id);
          } catch (error) {
            handleFirestoreError(error, OperationType.CREATE, 'chats');
          }
        }
      }
    } catch (error: any) {
      console.error('Chat Error:', error);
      
      let errorMessage = 'Lithium encountered an interference in the neural stream.';
      
      // Handle Rate Limit (Quota) Error
      const errStr = JSON.stringify(error).toLowerCase();
      if (errStr.includes('429') || errStr.includes('quota') || errStr.includes('resource_exhausted') || error?.status === 429) {
        errorMessage = 'Neural transmission limit reached. please wait a moment before re-synthesizing.';
      }
      
      setMessages(prev => [...prev, { role: 'assistant', content: errorMessage }]);
    } finally {
      setIsTyping(false);
    }
  };

  const QuickStartCard = ({ icon: Icon, title, onClick }: { icon: any, title: string, onClick: () => void }) => (
    <button 
      onClick={onClick}
      className="glass-card p-6 flex flex-col items-center gap-4 hover:border-brand-blue hover:bg-brand-blue/5 transition-all duration-300 group"
    >
      <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-brand-blue/20 transition-colors">
        <Icon size={24} className="text-brand-blue" />
      </div>
      <span className="text-sm font-medium text-white/70 group-hover:text-white transition-colors text-center">{title}</span>
    </button>
  );

  return (
    <div id="chat-container" className="flex flex-col h-full relative">
      {projectId && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-4">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 px-4 py-2 bg-brand-blue/10 border border-brand-blue/20 backdrop-blur-xl rounded-full"
          >
            <div className="flex items-center gap-2">
              <Folder size={14} className="text-brand-blue" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-blue">Active Project:</span>
              <button 
                onClick={() => {
                  const newName = prompt('Rename project:', projectName);
                  if (newName && user && projectId) {
                    updateDoc(doc(db, 'projects', projectId), { name: newName });
                    setProjectName(newName);
                  }
                }}
                className="text-xs font-bold text-white hover:text-brand-blue transition-colors"
                title="Rename Project"
              >
                {projectName}
              </button>
            </div>
            <div className="w-px h-3 bg-white/10 mx-1" />
            <div className="flex items-center gap-2">
              <button 
                onClick={onClearProject}
                className="text-[10px] font-bold text-white/40 hover:text-white transition-colors"
              >
                Exit
              </button>
              <span className="text-white/10 text-[10px]">|</span>
              <button 
                onClick={handleDeleteProject}
                className="text-[10px] font-bold text-white/20 hover:text-red-400 transition-colors"
              >
                Delete
              </button>
            </div>
          </motion.div>

          {activeIon && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-3 px-4 py-2 bg-brand-purple/10 border border-brand-purple/20 backdrop-blur-xl rounded-full"
            >
              <Sparkles size={14} className="text-brand-purple" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-purple">Active Ion:</span>
              <span className="text-xs font-bold text-white">{activeIon.name}</span>
              <div className="w-px h-3 bg-white/10 mx-1" />
              <button 
                onClick={onClearIon}
                className="text-[10px] font-black text-white/40 hover:text-white transition-colors"
              >
                UNSYNC
              </button>
            </motion.div>
          )}
        </div>
      )}

      {/* Solo active ion (no project) */}
      {!projectId && activeIon && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 px-6 py-3 bg-brand-purple/10 border border-brand-purple/20 backdrop-blur-xl rounded-full shadow-[0_0_30px_rgba(139,92,246,0.2)]"
          >
            <BrainCircuit size={18} className="text-brand-purple" />
            <div className="flex flex-col -mt-0.5">
              <span className="text-[9px] font-black uppercase tracking-[0.2em] text-brand-purple/60">Ion Neural Link</span>
              <span className="text-xs font-black text-white tracking-wide">{activeIon.name}</span>
            </div>
            <div className="w-px h-5 bg-white/10 mx-2" />
            <button 
              onClick={onClearIon}
              className="text-[10px] font-black text-white/30 hover:text-white transition-colors uppercase tracking-widest"
            >
              Disconnect
            </button>
          </motion.div>
        </div>
      )}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-8 px-6 pt-10 pb-40"
      >
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center max-w-4xl mx-auto py-10">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut"
              }}
              className="w-32 h-32 bg-brand-blue rounded-[2.5rem] flex flex-col items-center justify-center blue-glow mb-12 shadow-[0_0_60px_rgba(0,132,255,0.4)] relative overflow-hidden border-8 border-white/10"
            >
              <span className="text-2xl font-bold text-white/50 absolute top-4 left-6">3</span>
              <span className="text-7xl font-black text-white select-none mt-2">Li</span>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full"
            >
              <QuickStartCard 
                icon={Activity} 
                title="Stress-test Neural Tiers" 
                onClick={() => onQuickAction('test')} 
              />
              <QuickStartCard 
                icon={BrainCircuit} 
                title="Develop New Neural Ion" 
                onClick={() => setInput("Lithium, I want to create a new Ion. Help me engineer a specialized persona for...")} 
              />
              <QuickStartCard 
                icon={ImageIcon} 
                title="Synthesize New Visual" 
                onClick={() => setInput("Generate a cinematic masterpiece of ")} 
              />
              <QuickStartCard 
                icon={ShieldAlert} 
                title="Check System Status" 
                onClick={() => {}} 
              />
            </motion.div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto space-y-6 w-full">
            <AnimatePresence initial={false}>
              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-5 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-lg ${
                    msg.role === 'user' 
                      ? 'bg-brand-blue blue-glow font-bold' 
                      : 'bg-white/5 border border-white/10'
                  }`}>
                    {msg.role === 'user' ? 'U' : 'L'}
                  </div>
                  <div className={`glass-card p-5 max-w-[85%] border-white/5 leading-relaxed shadow-xl group relative ${
                    msg.role === 'user' ? 'bg-brand-blue/10 border-brand-blue/20' : ''
                  }`}>
                    {msg.role === 'user' && editingMessageIndex !== idx && (
                      <button 
                        onClick={() => {
                          setEditingMessageIndex(idx);
                          setEditInput(msg.content);
                        }}
                        className="absolute -left-12 top-1/2 -translate-y-1/2 p-2 text-white/20 hover:text-white opacity-0 group-hover:opacity-100 transition-all duration-300"
                        title="Edit Message"
                      >
                        <Edit3 size={16} />
                      </button>
                    )}

                    {msg.attachment && (
                      <div className="mb-4 rounded-xl overflow-hidden border border-white/10">
                        <img src={msg.attachment.url} alt="Attached" className="w-full max-h-64 object-cover" />
                      </div>
                    )}

                    {editingMessageIndex === idx ? (
                      <div className="space-y-3">
                        <textarea
                          autoFocus
                          value={editInput}
                          onChange={(e) => setEditInput(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-brand-blue min-h-[100px] resize-none"
                        />
                        <div className="flex gap-2 justify-end">
                          <button 
                            onClick={() => setEditingMessageIndex(null)}
                            className="text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-white px-3 py-1.5"
                          >
                            Cancel
                          </button>
                          <button 
                            onClick={() => handleEditMessage(idx)}
                            className="text-[10px] font-bold uppercase tracking-widest bg-brand-blue text-white px-3 py-1.5 rounded-lg shadow-lg shadow-brand-blue/20 hover:scale-105 transition-all"
                          >
                            Save Changes
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm font-medium text-white/90 whitespace-pre-wrap">
                          {msg.content.replace(/!\[.*?\]\(https:\/\/image\.pollinations\.ai\/prompt\/[^)]+\)/g, '').trim()}
                        </p>
                        {msg.content.includes('https://image.pollinations.ai') && !msg.attachment && (
                          <div className="mt-4 rounded-xl overflow-hidden border border-white/10 group relative">
                            <img 
                              src={msg.content.match(/\((https:\/\/image\.pollinations\.ai\/prompt\/[^)]+)\)/)?.[1] || ''} 
                              alt="Synthesized" 
                              className="w-full aspect-square object-cover"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <span className="text-[10px] font-black uppercase tracking-widest bg-brand-blue px-3 py-1 rounded-full">Neural Generation</span>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex gap-5"
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-white/5 border border-white/10 shrink-0">
                    <Loader2 size={20} className="text-brand-blue animate-spin" />
                  </div>
                  <div className="glass-card px-5 py-4 flex items-center">
                    <span className="flex gap-1.5">
                      <span className="w-1.5 h-1.5 bg-brand-blue rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                      <span className="w-1.5 h-1.5 bg-brand-blue rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                      <span className="w-1.5 h-1.5 bg-brand-blue rounded-full animate-bounce"></span>
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full max-w-3xl px-6 space-y-4">
        <AnimatePresence>
          {selectedFiles.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-wrap gap-2 px-2"
            >
              {selectedFiles.map((file, i) => (
                <div key={i} className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 pr-2">
                  <span className="text-[10px] font-bold text-white/60 truncate max-w-[100px]">{file.name}</span>
                  <button onClick={() => removeFile(i)} className="text-white/20 hover:text-red-400 transition-colors">
                    <X size={12} />
                  </button>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative group flex items-center gap-3">
          <input 
            type="file" 
            multiple 
            ref={fileInputRef} 
            onChange={handleFileSelect} 
            className="hidden" 
            accept="image/*,application/pdf,text/*"
          />
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setIsTierMenuOpen(!isTierMenuOpen)}
              className="h-[62px] px-5 bg-black/60 backdrop-blur-2xl border-2 border-white/10 rounded-full flex items-center gap-2 hover:border-brand-blue/50 transition-all duration-300"
            >
              <Zap size={18} className={selectedTier === 'Base' ? 'text-blue-400' : selectedTier === 'Pro' ? 'text-brand-blue' : 'text-red-400'} />
              <span className="text-xs font-bold uppercase tracking-wider">{selectedTier}</span>
              <ChevronUp size={14} className={`transition-transform duration-300 ${isTierMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {isTierMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: -10, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute bottom-full left-0 mb-4 w-64 glass-card bg-black/80 backdrop-blur-3xl border-white/10 p-2 shadow-2xl z-50 overflow-hidden"
                >
                  <p className="text-[10px] font-bold text-white/30 px-3 py-2 uppercase tracking-widest">Select Neural Tier</p>
                  <div className="space-y-1">
                    {tiers.map(tier => (
                      <button
                        key={tier.name}
                        onClick={() => {
                          setSelectedTier(tier.name);
                          setIsTierMenuOpen(false);
                        }}
                        className={`w-full flex flex-col items-start px-4 py-3 rounded-xl transition-all duration-200 group ${
                          selectedTier === tier.name ? 'bg-white/10' : 'hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <Zap size={14} className={tier.name === 'Base' ? 'text-blue-400' : tier.name === 'Pro' ? 'text-brand-blue' : 'text-red-400'} />
                          <span className={`text-sm font-bold ${selectedTier === tier.name ? 'text-white' : 'text-white/60'}`}>{tier.label}</span>
                        </div>
                        <span className="text-[10px] text-white/30 font-medium ml-5 group-hover:text-white/50 transition-colors">{tier.desc}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="relative flex-1 flex items-center gap-2 bg-black/60 backdrop-blur-2xl border-2 border-white/10 rounded-full px-4 pr-3 transition-all duration-500 focus-within:neon-border">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-white/30 hover:text-brand-blue transition-colors"
            >
              <Paperclip size={20} />
            </button>
            <input
              id="chat-input"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={`Sequence active on ${currentTier.label}...`}
              className="flex-1 bg-transparent py-5 focus:outline-none text-white placeholder:text-white/20"
            />
            <button
              id="send-button"
              onClick={handleSend}
              disabled={(!input.trim() && selectedFiles.length === 0) || isTyping}
              className={`bg-brand-blue p-3 rounded-full text-white transition-all duration-300 disabled:opacity-50 disabled:scale-95 ${
                (!input.trim() && selectedFiles.length === 0) || isTyping ? '' : 'breathing-glow'
              }`}
            >
              <Send size={22} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatTab;
