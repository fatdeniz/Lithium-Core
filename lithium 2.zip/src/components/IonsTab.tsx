import React from 'react';
import { Sparkles, Plus, Trash2, Edit3, Save, X, Bot, Zap, BrainCircuit, Target, Code, Palette, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth } from '../lib/firebase';
import { collection, query, where, onSnapshot, addDoc, updateDoc, deleteDoc, serverTimestamp, doc } from 'firebase/firestore';
import { useAuthState } from 'react-firebase-hooks/auth';

interface Ion {
  id: string;
  name: string;
  description: string;
  instructions: string;
  icon: string;
  color: string;
}

interface IonsTabProps {
  onSelectIon: (ion: Ion | null) => void;
  activeIonId?: string;
  onNavigateToChat: () => void;
}

const ICONS = ['Sparkles', 'Zap', 'BrainCircuit', 'Bot', 'Target', 'Code', 'Palette', 'MessageSquare'];
const COLORS = ['#3B82F6', '#8B5CF6', '#EC4899', '#10B981', '#F59E0B', '#6366F1'];

export const IonsTab: React.FC<IonsTabProps> = ({ onSelectIon, activeIonId, onNavigateToChat }) => {
  const [user] = useAuthState(auth);
  const [ions, setIons] = React.useState<Ion[]>([]);
  const [isCreating, setIsCreating] = React.useState(false);
  const [editingIon, setEditingIon] = React.useState<Ion | null>(null);
  
  // Form State
  const [name, setName] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [instructions, setInstructions] = React.useState('');
  const [icon, setIcon] = React.useState('Sparkles');
  const [color, setColor] = React.useState('#3B82F6');

  React.useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'ions'), where('userId', '==', user.uid));
    return onSnapshot(q, (snapshot) => {
      setIons(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ion)));
    });
  }, [user]);

  const handleSave = async () => {
    if (!user || !name.trim()) return;

    const ionData = {
      name,
      description,
      instructions,
      icon,
      color,
      userId: user.uid,
      updatedAt: serverTimestamp()
    };

    try {
      if (editingIon) {
        await updateDoc(doc(db, 'ions', editingIon.id), ionData);
      } else {
        await addDoc(collection(db, 'ions'), {
          ...ionData,
          createdAt: serverTimestamp()
        });
      }
      resetForm();
    } catch (e) {
      console.error('Error saving Ion:', e);
    }
  };

  const resetForm = () => {
    setIsCreating(false);
    setEditingIon(null);
    setName('');
    setDescription('');
    setInstructions('');
    setIcon('Sparkles');
    setColor('#3B82F6');
  };

  const startEditing = (ion: Ion) => {
    setEditingIon(ion);
    setName(ion.name);
    setDescription(ion.description);
    setInstructions(ion.instructions);
    setIcon(ion.icon);
    setColor(ion.color);
    setIsCreating(true);
  };

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (!confirm('Discard this Ion permanently?')) return;
    await deleteDoc(doc(db, 'ions', id));
  };

  return (
    <div className="h-full flex flex-col p-8 max-w-6xl mx-auto w-full">
      <div className="flex justify-between items-end mb-12">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <Sparkles className="text-brand-blue" />
            Neural Ions
          </h2>
          <p className="text-white/40 text-sm mt-2 font-medium">Create specialized sub-processors for custom logical domains.</p>
        </div>
        {!isCreating && (
          <button 
            onClick={() => setIsCreating(true)}
            className="bg-brand-blue/10 hover:bg-brand-blue/20 text-brand-blue border border-brand-blue/30 px-6 py-3 rounded-xl flex items-center gap-2 font-bold transition-all hover:scale-105 active:scale-95"
          >
            <Plus size={18} />
            Initialize Ion
          </button>
        )}
      </div>

      {isCreating ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 space-y-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-white/40 block mb-2">Ion Identity</label>
                <input 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Creative Director, Python Architect..."
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-brand-blue transition-colors font-medium"
                />
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-white/40 block mb-2">Short Objective</label>
                <input 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="One sentence about its purpose."
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-brand-blue transition-colors text-sm"
                />
              </div>
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/40 block mb-2">Neural Visual</label>
                  <div className="flex flex-wrap gap-2">
                    {ICONS.map(i => (
                      <button 
                        key={i}
                        onClick={() => setIcon(i)}
                        className={`p-3 rounded-lg border transition-all ${icon === i ? 'bg-brand-blue border-brand-blue' : 'bg-black/40 border-white/5 hover:border-white/20'}`}
                      >
                        {i === 'Sparkles' && <Sparkles size={16} />}
                        {i === 'Zap' && <Zap size={16} />}
                        {i === 'BrainCircuit' && <BrainCircuit size={16} />}
                        {i === 'Bot' && <Bot size={16} />}
                        {i === 'Target' && <Target size={16} />}
                        {i === 'Code' && <Code size={16} />}
                        {i === 'Palette' && <Palette size={16} />}
                        {i === 'MessageSquare' && <MessageSquare size={16} />}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/40 block mb-2">Sync Color</label>
                  <div className="flex gap-2">
                    {COLORS.map(c => (
                      <button 
                        key={c}
                        onClick={() => setColor(c)}
                        className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${color === c ? 'border-white' : 'border-transparent'}`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/40 block mb-2">Core Instructions & Behaviour</label>
              <textarea 
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="How should Lithium behave when this Ion is active? Define specialized knowledge and tone here."
                className="flex-1 w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-brand-blue transition-colors text-sm resize-none font-mono leading-relaxed"
              />
              <p className="mt-3 text-[10px] text-white/20 italic font-medium">Need help drafting? Lithium can assist in the Chat architecture.</p>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/5">
            <button 
              onClick={resetForm}
              className="px-6 py-2 text-white/40 hover:text-white font-bold uppercase tracking-widest text-xs transition-colors"
            >
              Discard
            </button>
            <button 
              onClick={handleSave}
              className="bg-brand-blue text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest text-xs shadow-lg shadow-brand-blue/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <Save size={16} />
              {editingIon ? 'Update Protocol' : 'Initialize Ion'}
            </button>
          </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ions.map(ion => (
            <motion.div
              layoutId={ion.id}
              key={ion.id}
              onClick={() => {
                onSelectIon(ion);
                onNavigateToChat();
              }}
              className={`glass-card p-6 group cursor-pointer border-white/10 hover:border-brand-blue/50 transition-all relative overflow-hidden flex flex-col h-full ${activeIonId === ion.id ? 'ring-2 ring-brand-blue' : ''}`}
            >
              <div 
                className="absolute top-0 right-0 w-32 h-32 opacity-10 translate-x-12 -translate-y-12 rounded-full"
                style={{ backgroundColor: ion.color }}
              />
              <div className="flex justify-between items-start relative z-10">
                <div 
                  className="p-3 rounded-xl mb-4"
                  style={{ backgroundColor: `${ion.color}20`, color: ion.color }}
                >
                  {ion.icon === 'Sparkles' && <Sparkles size={24} />}
                  {ion.icon === 'Zap' && <Zap size={24} />}
                  {ion.icon === 'BrainCircuit' && <BrainCircuit size={24} />}
                  {ion.icon === 'Bot' && <Bot size={24} />}
                  {ion.icon === 'Target' && <Target size={24} />}
                  {ion.icon === 'Code' && <Code size={24} />}
                  {ion.icon === 'Palette' && <Palette size={24} />}
                  {ion.icon === 'MessageSquare' && <MessageSquare size={24} />}
                </div>
                <div className="flex gap-1">
                  <button 
                    onClick={(e) => { e.stopPropagation(); startEditing(ion); }}
                    className="p-2 text-white/20 hover:text-white transition-colors"
                  >
                    <Edit3 size={14} />
                  </button>
                  <button 
                    onClick={(e) => handleDelete(e, ion.id)}
                    className="p-2 text-white/20 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <h3 className="text-xl font-black text-white mb-2 leading-tight">{ion.name}</h3>
              <p className="text-sm text-white/40 font-medium mb-6 flex-1 line-clamp-2">{ion.description || 'No description provided.'}</p>
              
              <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
                <span className="text-[10px] font-black uppercase tracking-widest text-white/20">Active Synapse</span>
                <button className="text-[10px] font-black uppercase tracking-widest text-brand-blue group-hover:underline">Deploy Ion</button>
              </div>
            </motion.div>
          ))}

          {/* Create Placeholder */}
          <button 
            onClick={() => setIsCreating(true)}
            className="glass-card p-6 border-dashed border-white/10 flex flex-col items-center justify-center gap-4 text-white/20 hover:text-white hover:border-brand-blue/30 transition-all group min-h-[220px]"
          >
            <div className="w-12 h-12 rounded-full border border-current flex items-center justify-center group-hover:scale-110 transition-transform">
              <Plus size={24} />
            </div>
            <span className="text-sm font-black uppercase tracking-[0.2em]">New Neural Ion</span>
          </button>
        </div>
      )}
    </div>
  );
};
