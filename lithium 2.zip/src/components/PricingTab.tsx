import React from 'react';
import { Check, Zap, Rocket, Crown } from 'lucide-react';
import { motion } from 'motion/react';

const PricingTab: React.FC = () => {
  const plans = [
    {
      name: 'Lithium-Base',
      price: '$0',
      description: 'Perfect for exploring the core Lithium engine.',
      icon: Zap,
      features: [
        'High-speed Chat access',
        'Standard image generation',
        '3 generations per day',
        'Community support',
      ],
      isPopular: false,
    },
    {
      name: 'Lithium-Pro',
      price: '$3.99',
      description: 'Optimized for power users needing more velocity.',
      icon: Rocket,
      features: [
        'Everything in Base',
        '100 generations per day',
        'Priority processing queue',
        'High-fidelity image modes',
        'Email support',
      ],
      isPopular: true,
    },
    {
      name: 'Lithium-Max',
      price: '$9.99',
      description: 'The ultimate Lithium experience without limits.',
      icon: Crown,
      features: [
        'Unlimited generations',
        'Exclusive Beta features',
        'Personal AI consultation',
        'API access keys',
        '24/7 dedicated support',
      ],
      isPopular: false,
    },
  ];

  return (
    <div id="pricing-container" className="py-20 px-8 max-w-7xl mx-auto">
      <div className="text-center space-y-4 mb-20">
        <h2 className="text-4xl md:text-6xl font-bold tracking-tighter">Choose your velocity.</h2>
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-brand-blue/20 border border-brand-blue/30 rounded-full">
          <span className="w-2 h-2 bg-brand-blue rounded-full animate-pulse" />
          <span className="text-xs font-black uppercase tracking-[0.2em] text-brand-blue">Early Access Special: 100% Free</span>
        </div>
        <p className="text-white/50 text-lg max-w-2xl mx-auto">Scalable AI performance tailored to your creative and professional requirements.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, idx) => {
          const Icon = plan.icon;
          const isPaidPlan = plan.price !== '$0';
          
          return (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`relative flex flex-col glass-card p-8 transition-transform hover:-translate-y-2 duration-500 ${
                plan.isPopular ? 'border-brand-blue/50 bg-brand-blue/5' : ''
              }`}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-brand-blue rounded-full text-[10px] font-bold uppercase tracking-widest blue-glow">
                  Most Popular
                </div>
              )}
              
              <div className="mb-8">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 ${
                  plan.isPopular ? 'bg-brand-blue text-white' : 'bg-white/10 text-white/60'
                }`}>
                  <Icon size={24} />
                </div>
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-2 mb-4">
                  {isPaidPlan ? (
                    <>
                      <span className="text-xl font-bold text-white/30 line-through decoration-brand-blue/50">{plan.price}</span>
                      <span className="text-4xl font-black text-white">$0</span>
                    </>
                  ) : (
                    <span className="text-4xl font-bold">{plan.price}</span>
                  )}
                  <span className="text-white/40 font-medium text-sm">/mo</span>
                </div>
                <p className="text-white/50 text-sm">{plan.description}</p>
              </div>

              <div className="flex-1 space-y-4 mb-8">
                {plan.features.map(feature => (
                  <div key={feature} className="flex items-start gap-3">
                    <div className="mt-1 w-4 h-4 bg-brand-blue/20 border border-brand-blue/30 rounded-full flex items-center justify-center shrink-0">
                      <Check size={10} className="text-brand-blue" />
                    </div>
                    <span className="text-sm text-white/70">{feature}</span>
                  </div>
                ))}
              </div>

              <button 
                id={`btn-select-${plan.name.toLowerCase()}`}
                className={`w-full py-3 rounded-xl font-bold transition-all ${
                  plan.isPopular 
                    ? 'bg-brand-blue text-white blue-glow hover:opacity-90' 
                    : 'bg-white text-black hover:bg-brand-blue hover:text-white'
                }`}
              >
                Get Started
              </button>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-20 text-center">
        <p className="text-white/30 text-sm">
          All plans include full data privacy. No hidden fees. Cancel anytime.
        </p>
      </div>
    </div>
  );
};

export default PricingTab;
