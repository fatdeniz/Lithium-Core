import React from 'react';
import { FolderPlus, Folder, MoreVertical, Trash2, Edit3, Plus, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc } from 'firebase/firestore';

interface Project {
  id: string;
  name: string;
  description: string;
  instructions: string;
  createdAt: any;
}

interface ProjectsTabProps {
  onSelectProject: (id: string) => void;
}

const ProjectsTab: React.FC<ProjectsTabProps> = ({ onSelectProject }) => {
  const [projects, setProjects] = React.useState<Project[]>([]);
  const [showCreateModal, setShowCreateModal] = React.useState(false);
  const [newProject, setNewProject] = React.useState({ name: '', description: '', instructions: '' });
  const [loading, setLoading] = React.useState(true);
  const user = auth.currentUser;

  React.useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'projects'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Project));
      setProjects(projs);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleCreateProject = async () => {
    if (!user || !newProject.name.trim()) return;

    try {
      await addDoc(collection(db, 'projects'), {
        userId: user.uid,
        name: newProject.name,
        description: newProject.description,
        instructions: newProject.instructions,
        createdAt: serverTimestamp()
      });
      setNewProject({ name: '', description: '', instructions: '' });
      setShowCreateModal(false);
    } catch (error) {
      console.error('Error creating project:', error);
    }
  };

  const handleDeleteProject = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this project?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id));
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black tracking-tight mb-2 italic">Neural Projects</h2>
          <p className="text-white/50">Organize your synthesis sequences into specialized workspaces.</p>
        </div>
        <button 
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 bg-brand-blue text-white px-6 py-3 rounded-full font-bold shadow-lg shadow-brand-blue/20 hover:scale-105 transition-all"
        >
          <Plus size={20} />
          Create Project
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {projects.map((project) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              key={project.id}
              onClick={() => onSelectProject(project.id)}
              className="glass-card p-6 group hover:border-brand-blue/50 transition-all cursor-pointer relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-40 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={(e) => handleDeleteProject(project.id, e)}
                  className="p-2 text-white hover:text-red-400 transition-colors bg-black/20 rounded-lg backdrop-blur-sm"
                  title="Delete Project"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="w-12 h-12 bg-brand-blue/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-blue/20 transition-colors">
                <Folder size={24} className="text-brand-blue" />
              </div>

              <h3 className="text-xl font-bold mb-2 truncate pr-8">{project.name}</h3>
              <p className="text-white/40 text-sm line-clamp-2 mb-6 h-10">
                {project.description || 'No description provided.'}
              </p>

              <div className="flex items-center justify-between pt-6 border-t border-white/5">
                <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">
                  Initialized: {project.createdAt?.toDate().toLocaleDateString() || 'Recent'}
                </span>
                <button className="text-xs font-bold text-brand-blue hover:underline">
                  Open Workspace →
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {!loading && projects.length === 0 && (
          <div className="col-span-full py-20 flex flex-col items-center justify-center glass-card border-dashed border-white/10 bg-transparent">
            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
              <FolderPlus size={32} className="text-white/20" />
            </div>
            <p className="text-white/40 font-medium">No projects found.</p>
            <p className="text-white/20 text-sm">Create your first workspace to start organizing.</p>
          </div>
        )}
      </div>

      {/* Modal Container */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateModal(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-xl glass-card border-white/10 bg-black/90 p-8 shadow-2xl"
            >
              <h2 className="text-2xl font-bold mb-6">Initialize New Project</h2>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2">Project Name</label>
                  <input 
                    autoFocus
                    type="text" 
                    value={newProject.name}
                    onChange={(e) => setNewProject({...newProject, name: e.target.value})}
                    placeholder="e.g. Advanced Mathematics" 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-blue transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2">Description</label>
                  <input 
                    type="text" 
                    value={newProject.description}
                    onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                    placeholder="Short summary of this workspace" 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-blue transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2">Custom Instructions (Optional)</label>
                  <textarea 
                    value={newProject.instructions}
                    onChange={(e) => setNewProject({...newProject, instructions: e.target.value})}
                    placeholder="Define how the AI should behave in this project..." 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-blue transition-all h-32 resize-none"
                  />
                </div>
                <div className="flex gap-4 pt-4">
                  <button 
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 px-6 py-3 rounded-xl border border-white/10 hover:bg-white/5 font-bold transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleCreateProject}
                    disabled={!newProject.name.trim()}
                    className="flex-2 bg-brand-blue text-white px-6 py-3 rounded-xl font-bold hover:opacity-90 disabled:opacity-50 transition-all blue-glow"
                  >
                    Initialize Project
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProjectsTab;
