import React from 'react';
import { Settings, User, Shield, Brain, Save, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { db, auth } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

interface UserSettings {
  customPersonality: string;
}

const SettingsTab: React.FC = () => {
  const [settings, setSettings] = React.useState<UserSettings>({ customPersonality: '' });
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [message, setMessage] = React.useState({ text: '', type: 'success' });
  
  const user = auth.currentUser;
  const isMaxTier = user?.email === 'thismustafa4@gmail.com';

  React.useEffect(() => {
    if (!user) return;

    const fetchSettings = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'userSettings', user.uid));
        if (docSnap.exists()) {
          setSettings(docSnap.data() as UserSettings);
        }
      } catch (error) {
        console.error('Error fetching settings:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
  }, [user]);

  const handleSave = async () => {
    if (!user || !isMaxTier) return;
    setSaving(true);
    try {
      await setDoc(doc(db, 'userSettings', user.uid), {
        userId: user.uid,
        customPersonality: settings.customPersonality,
        updatedAt: serverTimestamp()
      }, { merge: true });
      setMessage({ text: 'Neural profile synchronized successfully.', type: 'success' });
      setTimeout(() => setMessage({ text: '', type: 'success' }), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      setMessage({ text: 'Synchronization failed. Please check rules.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-brand-blue border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-10">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center">
          <Settings size={24} className="text-brand-blue" />
        </div>
        <div>
          <h2 className="text-3xl font-black tracking-tight italic">System Configuration</h2>
          <p className="text-white/50">Modify your global neural interface settings.</p>
        </div>
      </div>

      {!isMaxTier ? (
        <div className="glass-card p-12 flex flex-col items-center justify-center text-center gap-6 border-brand-blue/20 bg-brand-blue/5">
          <div className="w-16 h-16 bg-brand-blue/20 rounded-full flex items-center justify-center mb-2">
            <Shield size={32} className="text-brand-blue" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold italic tracking-tight">Access Restricted</h3>
            <p className="text-white/40 max-w-md">Custom Neural Personalities are exclusively available for <span className="text-brand-blue font-bold">Lithium MAX</span> users.</p>
          </div>
          <button className="bg-brand-blue text-white px-8 py-3 rounded-full font-bold blue-glow hover:scale-105 transition-all">
            Upgrade to Max
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          <div className="glass-card p-8 space-y-8">
            <div className="flex items-center gap-3 pb-6 border-b border-white/5">
              <Brain size={20} className="text-brand-blue" />
              <h3 className="text-lg font-bold">Neural Personality Profile</h3>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-white/30 uppercase tracking-widest pl-2">System Instructions</label>
                <span className="text-[10px] bg-brand-blue/20 text-brand-blue px-2 py-0.5 rounded-full font-bold">MAX EXCLUSIVE</span>
              </div>
              <textarea 
                value={settings.customPersonality}
                onChange={(e) => setSettings({...settings, customPersonality: e.target.value})}
                placeholder="Define your AI's global persona, tone, and formatting preferences..." 
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-5 focus:outline-none focus:border-brand-blue transition-all h-64 resize-none leading-relaxed text-white/90"
              />
              <p className="text-[10px] text-white/20 px-2 italic">This prompt will be injected into all future Lithium chat sequences.</p>
            </div>

            <div className="flex items-center justify-between pt-4">
              <div className="flex items-center gap-2">
                {message.text && (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`flex items-center gap-2 text-xs font-bold ${message.type === 'success' ? 'text-green-400' : 'text-red-400'}`}
                  >
                    <AlertCircle size={14} />
                    {message.text}
                  </motion.div>
                )}
              </div>
              <button 
                onClick={handleSave}
                disabled={saving}
                className="flex items-center gap-2 bg-brand-blue text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-brand-blue/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
              >
                {saving ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Save size={18} />
                )}
                Sync Protocol
              </button>
            </div>
          </div>

          <div className="glass-card p-8 flex items-center justify-between border-white/5">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center">
                <User size={20} className="text-white/40" />
              </div>
              <div>
                <p className="text-sm font-bold">Account Verification</p>
                <p className="text-xs text-white/30 truncate max-w-[200px]">{user.email}</p>
              </div>
            </div>
            <div className="px-4 py-1 bg-brand-blue/10 border border-brand-blue/30 rounded-full">
              <span className="text-[10px] font-black text-brand-blue italic uppercase tracking-tighter">MAX AUTHORIZED</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsTab;
