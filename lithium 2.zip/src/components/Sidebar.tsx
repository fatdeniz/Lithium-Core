import React from 'react';
import { MessageSquare, Image, CreditCard, Zap, Menu, X, Beaker, LogOut, FolderKanban, Settings, Plus, Clock, Trash2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { auth, db } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { collection, query, where, orderBy, onSnapshot, collectionGroup, deleteDoc, doc } from 'firebase/firestore';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeChatId: string | null;
  onChatSelect: (id: string) => void;
  onNewChat: () => void;
}

interface ChatHistory {
  id: string;
  title: string;
  updatedAt: any;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, activeChatId, onChatSelect, onNewChat }) => {
  const [isOpen, setIsOpen] = React.useState(true);
  const [recentChats, setRecentChats] = React.useState<ChatHistory[]>([]);
  const user = auth.currentUser;
  const isPrivileged = user?.email === 'thismustafa4@gmail.com';

  React.useEffect(() => {
    if (!user) return;

    const chatsRef = collection(db, 'chats');
    const q = query(
      chatsRef, 
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chats = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ChatHistory[];
      setRecentChats(chats);
    }, (error) => {
      console.error("Error fetching chats:", error);
    });

    return () => unsubscribe();
  }, [user]);

  const tabs = [
    { id: 'projects', label: 'Projects', icon: FolderKanban },
    { id: 'ions', label: 'Ions', icon: Sparkles },
    { id: 'pricing', label: 'Pricing', icon: CreditCard },
  ];

  return (
    <>
      <button 
        id="sidebar-toggle"
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 glass-button"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      <motion.aside
        id="sidebar"
        initial={false}
        animate={{ width: isOpen ? 280 : 0, opacity: isOpen ? 1 : 0 }}
        className="fixed lg:static inset-y-0 left-0 z-40 glass-sidebar overflow-hidden flex flex-col"
      >
        <div className="p-8 flex items-center gap-3">
          <div className="w-11 h-11 bg-brand-blue border-2 border-white/20 rounded-2xl flex flex-col items-center justify-center blue-glow relative overflow-hidden">
            <span className="text-[10px] font-bold text-white/50 absolute top-1 left-1.5">3</span>
            <span className="text-xl font-black text-white mt-1">Li</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tighter">Lithium</h1>
        </div>

        <nav className="flex-1 px-4 mt-2 space-y-6 overflow-y-auto">
          <div className="space-y-1">
            <button
              id="new-chat-btn"
              onClick={onNewChat}
              className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl transition-all duration-300 bg-brand-blue text-white blue-glow mb-4 hover:scale-[1.02] active:scale-95`}
            >
              <Plus size={20} />
              <span className="font-bold tracking-tight">New Synthesis</span>
            </button>

            <div className="space-y-2">
              <div className="flex items-center gap-2 px-4 mb-2">
                <Clock size={12} className="text-white/20" />
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/30">Recent Streams</p>
              </div>
              
              {recentChats.map((chat) => (
                <div key={chat.id} className="group flex items-center gap-1">
                  <button
                    onClick={() => onChatSelect(chat.id)}
                    className={`flex-1 flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                      activeChatId === chat.id 
                        ? 'bg-white/10 text-white' 
                        : 'text-white/40 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <MessageSquare size={16} className={activeChatId === chat.id ? 'text-brand-blue' : 'text-white/20 group-hover:text-white/40'} />
                    <span className="text-sm font-medium truncate">{chat.title || 'Genetic Sequence'}</span>
                  </button>
                  <button
                    onClick={async (e) => {
                      e.stopPropagation();
                      if (confirm('De-initialize this neural sequence?')) {
                        try {
                          await deleteDoc(doc(db, 'chats', chat.id));
                          if (activeChatId === chat.id) onNewChat();
                        } catch (error) {
                          console.error("Error deleting chat:", error);
                        }
                      }
                    }}
                    className="p-2 opacity-20 group-hover:opacity-100 hover:text-red-400 transition-all duration-300"
                    title="Delete Chat"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}

              {recentChats.length === 0 && (
                <div className="px-4 py-8 text-center border-2 border-dashed border-white/5 rounded-2xl">
                  <p className="text-[10px] uppercase font-bold tracking-widest text-white/10 italic">No existing streams</p>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-1 border-t border-white/5 pt-6">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 px-4 mb-2">Workspace</p>
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  id={`nav-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    isActive 
                      ? 'bg-white/10 text-white' 
                      : 'text-white/50 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium text-sm">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {isPrivileged && (
            <div className="pt-4 mt-4 border-t border-white/5">
              <p className="text-[10px] font-bold uppercase tracking-widest text-brand-blue px-4 mb-2">Beta Modules</p>
              <button
                id="nav-beta"
                onClick={() => setActiveTab('test')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                  activeTab === 'test' ? 'bg-white/10 text-white' : 'text-white/40 hover:bg-white/5'
                }`}
              >
                <Beaker size={20} className="text-brand-blue" />
                <span className="font-medium">Early Access Lab</span>
              </button>
            </div>
          )}
        </nav>

        <div className="p-6 space-y-6 bg-black/20">
          <div className="space-y-3">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 px-2">Lithium Tiers</p>
            <div className="space-y-1">
              {[
                { name: 'Base', active: false },
                { name: 'Pro', active: !isPrivileged },
                { name: 'Max', active: isPrivileged }
              ].map(tier => (
                <div key={tier.name} className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/5 transition-colors group">
                  <span className={`text-sm ${tier.active ? 'text-white font-bold' : 'text-white/40'}`}>{tier.name}</span>
                  {tier.active && (
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-brand-blue font-bold">ACTIVE</span>
                      <div className="w-2 h-2 bg-brand-blue rounded-full shadow-[0_0_8px_#0084FF] animate-pulse" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-white/5 space-y-4">
            <div className="flex items-center gap-3 px-2">
              <button 
                onClick={() => setActiveTab('settings')}
                className="relative group"
              >
                {user?.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full border border-white/10 group-hover:border-brand-blue transition-colors" />
                ) : (
                  <div className="w-8 h-8 bg-white/5 rounded-full flex items-center justify-center text-xs font-bold text-white/40 group-hover:bg-brand-blue/20 transition-colors">
                    {user?.displayName?.charAt(0) || 'U'}
                  </div>
                )}
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-brand-blue rounded-full border-2 border-brand-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Settings size={6} className="text-white" />
                </div>
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate">{user?.displayName || 'Authorized User'}</p>
                <div className="flex items-center gap-1.5 overflow-hidden">
                  <p className="text-[10px] text-white/30 truncate">{user?.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setActiveTab('settings')}
                  className="p-1.5 text-white/20 hover:text-white transition-colors"
                  title="Settings"
                >
                  <Settings size={14} />
                </button>
                <button 
                  onClick={() => signOut(auth)}
                  className="p-1.5 text-white/20 hover:text-red-400 transition-colors"
                  title="Sign Out"
                >
                  <LogOut size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
};

export default Sidebar;
