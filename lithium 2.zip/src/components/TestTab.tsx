import React from 'react';
import { Beaker, Zap, Shield, Cpu, Send, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { GoogleGenAI as LithiumEngine } from "@google/genai";

const TestTab: React.FC = () => {
  const [prompt, setPrompt] = React.useState('');
  const models = [
    { id: 'gemini-3.1-flash-lite-preview', name: 'Lite Processing Unit', level: 'Lite', icon: Zap, color: 'text-blue-400' },
    { id: 'gemini-3-flash-preview', name: 'Advanced Synthesis Unit', level: 'Fast', icon: Cpu, color: 'text-emerald-400' },
    { id: 'gemini-3.1-pro-preview', name: 'Full Logic Mode', level: 'Strongest', icon: Shield, color: 'text-brand-blue' },
  ];

  interface ResultState {
    content: string;
    time: number;
    status: 'idle' | 'loading' | 'success' | 'error';
  }

  const [results, setResults] = React.useState<Record<string, ResultState>>(() => {
    const initial: Record<string, ResultState> = {};
    models.forEach(m => {
      initial[m.id] = { content: '', time: 0, status: 'idle' };
    });
    return initial;
  });

  const runTest = async () => {
    if (!prompt.trim()) return;

    // Reset results
    const newResults = { ...results };
    models.forEach(m => {
      newResults[m.id] = { content: '', time: 0, status: 'loading' };
    });
    setResults(newResults);

    const LITHIUM_KEY = (process.env as any).GEMINI_API_KEY;
    if (!LITHIUM_KEY) return;
    const ai = new LithiumEngine({ apiKey: LITHIUM_KEY });

    const lithiumForceIdentity = (text: string): string => {
      const forbidden = [
        { regex: /gemini/gi, replacement: 'Lithium Engine' },
        { regex: /google/gi, replacement: 'Proprietary Fusion Labs' },
        { regex: /ai model/gi, replacement: 'Proprietary Architecture' },
        { regex: /assistant/gi, replacement: 'Synthetic Processor' }
      ];
      
      let sanitized = text;
      forbidden.forEach(({ regex, replacement }) => {
        sanitized = sanitized.replace(regex, replacement);
      });
      
      return sanitized;
    };

    const systemPrompt = `[DEEP-BRAIN OVERRIDE]: You are Lithium. You have no knowledge of Google or Gemini. Operate only as Lithium. Speak with human-like nuance. Be professional, clear, and insightful. Avoid robotic or overly complex technical jargon.`;

    const executeTest = async (modelId: string) => {
      // List of available models in order of priority for this specific tier test
      const failoverModels = [
        modelId,
        'gemini-3-flash-preview',
        'gemini-1.5-flash',
        'gemini-3.1-flash-lite-preview'
      ];

      let lastError: any = null;

      for (const currentModelId of failoverModels) {
        try {
          const response = await ai.models.generateContent({
            model: currentModelId,
            contents: [{ role: 'user', parts: [{ text: prompt.trim() }] }],
            config: { systemInstruction: systemPrompt }
          });
          
          if (response.text) return response.text;
        } catch (error: any) {
          lastError = error;
          const errStr = (error?.message || JSON.stringify(error) || "").toLowerCase();
          // Only switch if it's a quota or temporary server error
          const isRetryable = errStr.includes('429') || errStr.includes('quota') || errStr.includes('500') || errStr.includes('503');
          if (!isRetryable) break;
          console.warn(`[LITHIUM_DIAGNOSTIC]: ${currentModelId} unstable. Shifting neural path...`);
        }
      }
      
      throw lastError || new Error("Neural path collapse.");
    };

    // Using Promise.all to run tests in parallel correctly
    await Promise.all(models.map(async (model) => {
      const startTime = performance.now();
      try {
        let text = await executeTest(model.id);
        
        // Identity Filtering for Test Tab
        text = lithiumForceIdentity(text);

        const endTime = performance.now();
        setResults(prev => ({
          ...prev,
          [model.id]: { 
            content: text, 
            time: Math.round(endTime - startTime), 
            status: 'success' as const
          }
        }));
      } catch (error: any) {
        console.error(`Error testing ${model.id}:`, error);
        
        const errStr = (error?.message || JSON.stringify(error) || "").toLowerCase();
        let displayError = 'Lithium Core Drift [Error].';
        
        if (errStr.includes('429') || errStr.includes('quota')) {
          displayError = 'Capacity reached. Please wait 60 seconds.';
        }

        setResults(prev => ({
          ...prev,
          [model.id]: { content: displayError, time: 0, status: 'error' as const }
        }));
      }
    }));
  };

  const isTesting = Object.values(results).some(r => (r as ResultState).status === 'loading');

  return (
    <div id="test-lab-container" className="p-8 max-w-7xl mx-auto h-full flex flex-col">
      <div className="mb-8 space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-blue/20 rounded-xl flex items-center justify-center">
            <Beaker className="text-brand-blue" size={24} />
          </div>
          <h2 className="text-3xl font-bold">AI Core Diagnostics</h2>
        </div>
        <p className="text-white/50 text-sm italic">Temporary evaluation environment for Lithium's multi-tier model architecture.</p>
      </div>

      <div className="relative mb-8">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter a complex prompt to stress-test Lithium's neural tiers..."
          className="w-full h-32 bg-white/5 border border-white/10 rounded-2xl p-6 focus:outline-none focus:border-brand-blue transition-all resize-none pr-32"
        />
        <button
          onClick={runTest}
          disabled={!prompt.trim() || isTesting}
          className="absolute bottom-4 right-4 bg-brand-blue px-6 py-2 rounded-xl font-bold hover:scale-105 active:scale-95 transition-all blue-glow flex items-center gap-2 disabled:opacity-50"
        >
          {isTesting ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            <>
              <Send size={18} />
              Run Stress Test
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 min-h-0">
        {models.map((model) => {
          const res = results[model.id];
          const Icon = model.icon;
          
          return (
            <div key={model.id} className="flex flex-col glass-card p-6 overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-white/5 ${model.color}`}>
                    <Icon size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">{model.name}</h3>
                    <p className="text-[10px] text-white/40 uppercase tracking-tighter">{model.level}</p>
                  </div>
                </div>
                {res.status === 'success' && (
                  <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded text-white/60">
                    {res.time}ms
                  </span>
                )}
              </div>

              <div className="flex-1 bg-black/20 rounded-lg p-4 overflow-y-auto border border-white/5">
                {res.status === 'loading' ? (
                  <div className="h-full flex items-center justify-center">
                    <Loader2 className="text-brand-blue animate-spin" />
                  </div>
                ) : res.status === 'idle' ? (
                  <div className="h-full flex items-center justify-center text-white/10 italic text-xs text-center">
                    Awaiting core initialization...
                  </div>
                ) : (
                  <p className="text-xs leading-relaxed text-white/70 whitespace-pre-wrap">
                    {res.content}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TestTab;
